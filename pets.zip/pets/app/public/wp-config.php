<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}


define('AUTH_KEY',         'i/elL/azGRbWpPXU2TXlP/y3aX+7jyrl0a/8A3/tBdvPY5q4r4fAxfyWpkR3WDWdqX+IauWtk5ObvleTB12fKA==');
define('SECURE_AUTH_KEY',  'JhOC+dEr/N+o6NYv9yelX1b3Fxh/yPXJznwzngAwpxNZLzZpRklfSxgcpUaW8lvy82Wp0q2hph02CLgxFn4IBA==');
define('LOGGED_IN_KEY',    'L4NgOktbNnRJpUqjPmFqr32sxkULGq5Au0H8by2BGNsrTONYyX78tUPvt6gbasdsjUhOqBK4hix1i6Z9CoZJtw==');
define('NONCE_KEY',        'C/vWatq5f+yUmueWdcdbMtZQkp16grFsdjRtFVYo7LIfnVe4dg6CC8wkjDdx4wpMtts5jtmFqMMerUS/4+GkEg==');
define('AUTH_SALT',        'fd4s02SMzpHoR9jCusITmAPwk0cyz05AIFB2TEYsd50rp1Y8K3Ee+g+PsZlI6HpXwK4tG70FFBytqYrhnF1dzQ==');
define('SECURE_AUTH_SALT', '/rXvpD2zc4uoXjU04DfvVetYnOo0HJH1Ma3+r8PJZY51PONWQgYiE8DKb9FJHaMxQaUsEbG+BsmIdQVw7Kumdg==');
define('LOGGED_IN_SALT',   'kch5U1Ati+JymnNSEbedSPyQEp4pACprBuuqKnoY5/Yd9tKkXBNYZUrXvM241chxO/STtb6ES/7eZYJkg6fOcg==');
define('NONCE_SALT',       '3qVrDzggSj/ZDveG37v10Jo5xnKQ1I8v+z9VwVhH3UeWvufUeU4gzjzfDd9fr6jTNKTdqMEXiQUZhsrHX4sDeQ==');
define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
